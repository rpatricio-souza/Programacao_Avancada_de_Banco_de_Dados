desc employees;
select * from employees;

insert into employees values(1,'Rafael','Patricio','rafael@email.com',null,'20/05/90','IT_PROG',null,null,null,null);

delete from employees where employee_id=1;

select department_id from departments;
insert into employees values(1,'Rafael','Patricio','rafael@email.com',null,'20/05/90','IT_PROG',null,null,null,15);
